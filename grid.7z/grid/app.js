var ws;

var table = {
    rows: []
};

var row = {
    id: "",
    timeReceived: "",
    status: "",
    bidRate: "",
    askRate: "",
    bidSize: "",
    askSize: ""
};

var dataStatusApp = new Vue({
    el: "#dataStatusApp",
    created() {
        for (let i = 1; i < 50; i++) {
            this.dataStatus[i] = { 
                id: i,
                timeReceived: i,
                status: 0,
                bidRate: i,
                askRate: i,
                bidSize: i,
                askSize: i 
            };
        }
        this.timer = setInterval(() => {
            let id = Math.floor(Math.random() * 49 + 1),
                value = Math.random() * 509;
            status = Math.floor(Math.random() * 20);
            this.setDataStatusById({
                id: id,
                timeReceived: Date.now(),
                status: status > 1 ? 2 : status,
                bidRate: value,
                askRate: value*1.25,
                bidSize: Math.floor(value/10),
                askSize: Math.floor(value/7) 
            });
        }, 0);
    },  
    beforeDestroy () {
        clearInterval(this.timer);
    },
    computed: {
        data () { return this.dataStatus || {}; },
    },
    methods: {
      
        setDataStatusById (param) {
            this.dataStatus[param.id] = param;
            this.setObjReactive (this.dataStatus);
        },
          
        setObjReactive (obj) {      
        /* vue.js имеет баг при реактивности сложных объектов, этот хак
        вызывает принудительное обновление объекта для реактивности*/
            Vue.set(obj, "setObjReactive", 42); 
            Vue.delete(obj, "setObjReactive");
        },
    },
    data: {
        timer: 0,
        dataStatus: {id: {}},
        tableStyle: "caption black white--text",
        tableHeaderStyle: "primary",
        tableBodyStyle: "grey lighten-5 black--text font-weight-light",
        statusColor: {
            "0": "",
            "2": "green accent-1",
            "1": "red accent-1"


        }
    }
});

// function connect() {
//     ws = new WebSocket("ws://" + document.location.host + "/stream");
//     return ws;
// }

// ws = connect();

// ws.onmessage = function (event) {
//     var tb = document.getElementById("dataStatus");
//     var message = JSON.parse(event.data);
//     console.log(message);
//     // var inputRow = new row;
//     tb.innerHTML = message.toString();
// };